package com.example.aves1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class aves2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aves2);
    }

    public void Anterior(View view) {
        Intent anterior = new Intent(this, MainActivity.class);

        startActivity(anterior);

    }
    public void Ave1(View view) {
        Intent ave1 = new Intent(this, secretario.class);
        startActivity(ave1);


    }
    public void Ave2(View view) {
        Intent ave2 = new Intent(this, podargo.class);
        startActivity(ave2);
    }
    public void Ave3(View view) {
        Intent ave3 = new Intent(this, urraca.class);
        startActivity(ave3);
    }
    public void Ave4(View view) {
        Intent ave4 = new Intent(this, columbida.class);
        startActivity(ave4);
    }
    public void Ave5(View view) {
        Intent ave5 = new Intent(this, bengali.class);
        startActivity(ave5);
    }public void Ave6(View view) {
        Intent ave6 = new Intent(this, azulejo.class);
        startActivity(ave6);
    }
    public void Ave7(View view) {
        Intent ave7 = new Intent(this, bigotudo.class);
        startActivity(ave7);
    }
    public void Ave8(View view) {
        Intent ave8 = new Intent(this, ampelis.class);
        startActivity(ave8);
    }
    public void Ave9(View view) {
        Intent ave9 = new Intent(this, gallina.class);
        startActivity(ave9);
    }
    public void Ave10(View view) {
        Intent ave10 = new Intent(this, arpia.class);
        startActivity(ave10);
    }



    }